const { supabase, cors, num, now_, mapTx } = require('./_lib/db');
const { randomUUID } = require('crypto');

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    // POST — add transaction (one or many items share same txId)
    if (req.method === 'POST') {
      const d = req.body;
      const txId = randomUUID();
      const ts   = now_();

      const rows = (d.items || []).map(item => {
        const u  = num(item.totalUnits);
        const pp = num(item.purchasePrice);
        const sp = num(item.sellingPrice);
        return {
          tx_id:         txId,
          type:          d.type,
          sr_id:         d.srId   || '',
          sr_name:       d.srName || '',
          date:          d.date,
          slip_no:       d.slipNo || '',
          product_id:    String(item.productId  || ''),
          product_name:  String(item.productName|| ''),
          sku:           String(item.sku        || ''),
          cases:         num(item.cases),
          pcs:           num(item.pcs),
          total_units:   u,
          purchase_price: pp,
          selling_price:  sp,
          total_cost:    u * pp,
          total_revenue: u * sp,
          note:          d.note || '',
          created_at:    ts
        };
      });

      const { error: txErr } = await supabase.from('transactions').insert(rows);
      if (txErr) throw txErr;

      // Auto-create damage claims for 'damage' type
      if (d.type === 'damage') {
        const dmgRows = (d.items || []).map(item => {
          const u  = num(item.totalUnits);
          const pp = num(item.purchasePrice);
          return {
            tx_id:         txId,
            product_id:    String(item.productId   || ''),
            product_name:  String(item.productName || ''),
            sku:           String(item.sku         || ''),
            total_units:   u,
            purchase_price: pp,
            total_cost:    u * pp,
            date:          d.date,
            sr_id:         d.srId   || '',
            sr_name:       d.srName || '',
            status:        'pending',
            cleared_date:  null,
            created_at:    ts
          };
        });
        const { error: dmgErr } = await supabase.from('dmg_claims').insert(dmgRows);
        if (dmgErr) throw dmgErr;
      }

      return res.json({ ok: true, txId });
    }

    // GET — list transactions with optional date filter
    if (req.method === 'GET') {
      const { from, to } = req.query;
      let q = supabase.from('transactions').select('*').order('created_at');
      if (from) q = q.gte('date', from);
      if (to)   q = q.lte('date', to);
      const { data, error } = await q;
      if (error) throw error;
      return res.json((data || []).map(mapTx));
    }

    res.status(405).json({ ok: false, error: 'Method not allowed' });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
};
